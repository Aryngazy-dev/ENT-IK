import { defineConfig, devices } from "@playwright/test";
export default defineConfig({ testDir: "./tests/e2e", timeout: 30_000, use: { baseURL: process.env.PLAYWRIGHT_BASE_URL ?? "http://127.0.0.1:3000", trace: "on-first-retry" }, projects: [{ name: "mobile-chrome", use: { ...devices["Pixel 5"] } }, { name: "desktop-chrome", use: { ...devices["Desktop Chrome"] } }] });
